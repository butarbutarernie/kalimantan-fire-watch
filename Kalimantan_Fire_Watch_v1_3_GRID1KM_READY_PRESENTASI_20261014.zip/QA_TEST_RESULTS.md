# QA Summary - v1.3 (14 October 2026)

Automated test result: 5 / 5 PASS (`tests/test_grid_1km.py`).

Verified independently:
- 75,278 FIRMS VIIRS records -> exactly 13,151 spatial grid cells (EPSG:6933, 1km)
- 2,048 VIIRS high-confidence records preserved
- 38,040 FIRMS centroid records intersect gambut soil-map units (same as previous QC)
- 426 qualifying 1km screening cells, 283 containing >=1 centroid in peat mapping units
- WorldCover 2021 pilot CSV has 12 1km cells, exactly 11 match 1km cells with active observations
- Same 426 candidate labels obtained by independently reaggregating the raw FIRMS ZIP
- Interactive Folium map builds and serializes to HTML
- Python compilation successful

**Not tested:** Streamlit Cloud deployment, current live API reachability, TerraScope WMS availability.

The 1km grid is an operational design choice for presentation; it has NOT been validated as statistically optimal for landscape wildfire screening.

The geospatial data do NOT measure burned area, verified fire incidents or risk probabilities.
