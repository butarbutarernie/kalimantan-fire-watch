import sys
from pathlib import Path
import pandas as pd
import numpy as np
from pyproj import Transformer
P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P))
from grid_1km import add_grid_id,aggregate_1km,attach_worldcover,candidate_geojson
from view_1km import make_screening_map


def test_snapshot_counts_and_unique_ids():
    g=pd.read_csv(P/'data/snapshot_grid_1km_20261007_13.csv')
    assert len(g)==13151
    assert g.grid_id.nunique()==len(g)
    assert g.n_detections.sum()==75278
    assert g.n_high.sum()==2048
    assert g.n_peat_detections.sum()==38040
    assert g.candidate.sum()==426
    assert ((g.candidate) & (g.n_peat_detections.gt(0))).sum()==283
    assert g.wc_available.sum()==11


def test_one_km_point_cell_and_geom():
    data=pd.DataFrame({'province':['Kalimantan Tengah','Kalimantan Barat'],
                       'latitude':[-1.2,-1.2],'longitude':[113.8,113.8]})
    gid=add_grid_id(data)
    assert gid.grid_id.iloc[0].startswith('KT_')
    assert gid.grid_id.iloc[1].startswith('KB_')
    assert gid.grid_id.str.endswith('_1000').all()
    df=pd.read_csv(P/'data/snapshot_grid_1km_20261007_13.csv')
    gj=candidate_geojson(df.loc[df.candidate])
    assert len(gj['features'])==426
    assert gj['features'][0]['geometry']['type']=='Polygon'


def test_reaggregation_rule_and_missing_peat():
    data=pd.DataFrame({'province':['Kalimantan Tengah']*3,'latitude':[-2.2]*3,'longitude':[113.3]*3,
      'acq_utc':pd.to_datetime(['2026-10-10T02:00Z','2026-10-11T02:00Z','2026-10-13T02:00Z'],utc=True),
      'source_family':['VIIRS']*3,'source_name':['S-NPP','NOAA-20','NOAA-21'],
      'confidence_group':['Nominal','Nominal','Tinggi'],'frp':[2.2,3.0,1.2]})
    ag=aggregate_1km(data,'2026-10-14T03:00Z')
    assert len(ag)==1 and ag.candidate.iloc[0]
    assert pd.isna(ag.n_peat_detections.iloc[0]) # absence != peat 0


def test_map_builds_and_popup_has_caveat():
    g=pd.read_csv(P/'data/snapshot_grid_1km_20261007_13.csv')
    m=make_screening_map(g)
    body=m.get_root().render()
    assert '1km screening candidates' in body
    assert 'WorldCover 2021' in body


def test_worldcover_join_1km_exact():
    a=pd.read_csv(P/'data/snapshot_grid_1km_20261007_13.csv').drop(columns=['wc_available'])
    wc=pd.read_csv(P/'data/pilot_wc1km_verified.csv')
    c,n=attach_worldcover(a,wc)
    assert n==11
    assert c.grid_id.nunique()==13151
    assert c.loc[~c.wc_available,'wc_dominant_class'].isna().all()
