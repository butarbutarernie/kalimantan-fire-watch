# Kalimantan Fire Watch v1.3 - Grid 1 km (14 Oktober 2026)

## Untuk presentasi SEKARANG

1. Buka **Kalimantan_FireWatch_1km_PRESENTATION_INTERACTIVE_20261014.html** dengan browser untuk peta interaktif.
2. Buka **RINGKASAN_PRESENTASI_1KM_20261014.html** untuk satu halaman angka utama dan narasi yang aman secara ilmiah.
3. Data pada kedua HTML adalah **snapshot 7-13 Oktober 2026**, diekspor 14 Oktober 2026 pukul 03:14 UTC. BUKAN data live.

## Mengganti dashboard Streamlit GitHub

1. Buka repository `https://github.com/butarbutarernie/kalimantan-fire-watch`.
2. Klik **Add file > Upload files**, unggah seluruh isi folder pada level akar: `streamlit_app.py`, `grid_1km.py`, `view_1km.py`, `fire_core.py`, `land_context.py`, `requirements.txt`, dan folder `data/` beserta CSV dan JSON di dalamnya. **Pertahankan struktur folder `data/`**; jangan unggah satu ZIP sebagai pengganti source.
3. Commit changes pada branch `main` dan tunggu deployment otomatis Streamlit Cloud. Bila error `FileNotFoundError`, pastikan file di folder `data` berada pada lokasi yang benar.
4. Buka dashboard. Pilih `Snapshot audit 7-13 Okt 2026` untuk presentasi. Pilih `NASA FIRMS terbaru (API)` untuk pembaruan data; MAP_KEY tetap disimpan pada Streamlit Secrets, tidak di repository.

## Isi fitur

- Peta dan tabel kandidat peninjauan grid **1 x 1 km**, EPSG:6933.
- Seluruh provinsi Kalimantan Indonesia: Kalbar, Kalteng, Kalsel, Kaltim, Kaltara.
- Filter provinsi, minimal hari terdeteksi, kandidat peninjauan, dan bukti centroid pada gambut.
- Bar chart provinsi, tren harian, dan ekspor CSV/GeoJSON.
- Ringkasan gambut berdasarkan koordinat pusat FIRMS yang beririsan dengan satuan peta gambut.
- ESA WorldCover 2021 hanya pada **11 sel dengan deteksi** dari **12 sel pilot** yang telah diproses. Semua sisanya tetap **missing/not evaluated**, tidak diimputasi.
- Mode API baru dapat mengambil VIIRS dan MODIS dengan NASA MAP_KEY. MODIS dipisahkan dalam provenance; tidak disamakan confidence-nya dengan VIIRS.

## Provenance, metode, dan batasan

- Data FIRMS: `Kalimantan_FireWatch_NASA_FIRMS_LIVE_20261014_0314.zip`, 75.278 deteksi dari 7-13 Oktober 2026 UTC, sensor S-NPP/NOAA-20/NOAA-21.
- Tiga satelit **VIIRS** tersebut bukan 75.278 kejadian kebakaran yang berbeda.
- Grid: titik pusat FIRMS ditransformasi WGS84 > EPSG:6933, dibagi ke sel 1000 x 1000 m. Satu titik pada batas grid bergantung aturan floor; label provinsi dipertahankan dari QC ADM1.
- Kriteria kandidat eksploratif: deteksi pada minimal 3 tanggal UTC; minimal 2 sensor VIIRS; minimal 1 VIIRS high confidence; observasi terakhir maksimal 72 jam sebelum waktu ekspor sumber. Ambang bukan standard operasional resmi atau model risiko terkalibrasi.
- Dari data snapshot terdapat **13.151 sel** dengan deteksi, **426 kandidat**, dan **283 kandidat** dengan >=1 pusat deteksi di poligon satuan peta gambut. Ini bukan luas gambut terbakar atau jumlah api unik.
- Gambut: turunan hasil spatial join centroid ke geometri sumber (file GeoPackage mentah **tidak dimasukkan paket publik**); sumber peta satuan tanah gambut skala 1:50.000 yang diunggah pengguna. Persentase centroid pada gambut **bukan fraksi area gambut per grid**.
- WorldCover 2021 v200: klasifikasi 10 m; bersifat baseline historis 2021, bukan kondisi permukaan 2026. Dalam snapshot hanya 11 dari 13.151 sel berisi statistik LULC yang sudah diuji, jangan melakukan generalisasi pulau.
- Dalam mode API realtime, konteks gambut belum tersedia sampai GeoPackage privat diunggah pada sesi tersebut. Data snapshot tidak digunakan diam-diam sebagai gambut untuk tanggal lain.
- GIS/risk validity: belum ada verifikasi insiden lapangan, uji ambang dan grid origin, normalisasi overpass dan tutupan awan, maupun burned-area yang terukur. Tidak boleh digunakan sendirian untuk memutuskan evakuasi atau operasi pemadaman.
- Snapshot 7 hari **tidak akan diperbarui otomatis**. Data API diperbarui ketika tombol/sesi pengguna memicu permintaan dan ketersediaan NASA memungkinkan.
- ESA WorldCover v200: CC BY 4.0; NASA FIRMS: NASA FIRMS.

## Keamanan

JANGAN unggah MAP_KEY NASA, `.streamlit/secrets.toml`, GeoPackage gambut mentah (sebelum izin redistribusi terverifikasi), atau file sensitif lain ke repository Public.

## Validasi paket

Pemeriksaan: 75.278 deteksi tepat dibagi menjadi 13.151 grid, 2.048 VIIRS high confidence, 38.040 centroid beririsan satuan peta gambut, dan 426 kandidat dengan ambang yang diumumkan. Join WorldCover menggunakan kunci `grid_id` 1 km dan hanya 11 sel ada datanya.

**Atribusi:** NASA FIRMS; ESA WorldCover 2021 v200 / ESA WorldCover consortium; peta gambut dari pengguna; `EPSG:6933`; kode dashboard proyek Kalimantan Fire Watch.
