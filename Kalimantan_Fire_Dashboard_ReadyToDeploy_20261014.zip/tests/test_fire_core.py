import json
from datetime import date, datetime, timezone

import numpy as np
import pandas as pd
import pytest
from shapely.geometry import Polygon, mapping

from fire_core import (
    PROVINCES, SourceError, _fetch_sensor_chunk, assign_provinces,
    canonical_province, clean_key, cluster_detections, demo_detections,
    detections_geojson, fetch_firms, normalize_firms, period_chunks,
    read_provinces_geojson, temporal_filter, to_feature_collection,
)

NOW = datetime(2026, 10, 14, 4, 0, tzinfo=timezone.utc)


def polygons_fixture():
    """Synthetic boxes for function tests; are NOT real administrative boundaries."""
    return {name: Polygon([(108+i*2,-3),(110+i*2,-3),(110+i*2,-1),(108+i*2,-1)])
            for i,name in enumerate(PROVINCES)}


def test_period_chunks_7_days_and_max_5_per_api_call():
    chunks = period_chunks(date(2026, 10, 14), 7)
    assert chunks == [(date(2026,10,8),5), (date(2026,10,13),2)]
    assert sum(n for _,n in chunks) == 7


def test_key_validation():
    assert clean_key(' ABCD12345678 \n') == 'ABCD12345678'
    for bad in ['', 'short', 'contains/slash', 'test?query=x']:
        with pytest.raises(SourceError): clean_key(bad)


def test_province_names():
    assert canonical_province('East Kalimantan') == 'Kalimantan Timur'
    assert canonical_province('Kalimantan Tengah') == 'Kalimantan Tengah'
    assert canonical_province('Sabah') is None
    assert canonical_province('Sarawak') is None


def test_normalize_timezone_conf_and_quality():
    raw = pd.DataFrame({
        'latitude': [-2.2, -2.2, 'bad'], 'longitude': [113, 113, 111],
        'acq_date': ['2026-10-13','2026-10-13','2026-10-13'],
        'acq_time': ['45','45','bad'], 'confidence': ['h','h','n'],
        'frp': [10,10,5], 'source_name': ['NOAA-20']*3,
    })
    normalized, qc = normalize_firms(raw, NOW)
    assert qc == {'raw_records':3,'invalid_or_missing':1,'exact_duplicates':1,'valid_records':1}
    assert normalized.iloc[0].acq_utc.strftime('%Y-%m-%d %H:%M UTC') == '2026-10-13 00:45 UTC'
    assert normalized.iloc[0].confidence_group == 'Tinggi'


def test_clip_excludes_border_neighbor():
    d = pd.DataFrame({'latitude':[-2,-2,-2], 'longitude':[109,111,119]})
    actual = assign_provinces(d, polygons_fixture())
    assert len(actual)==2
    assert set(actual.province)=={'Kalimantan Barat','Kalimantan Tengah'}


def test_geojson_five_provinces():
    features = [{'type':'Feature','properties':{'shapeName':name},
                 'geometry':mapping(geom)} for name,geom in polygons_fixture().items()]
    found = read_provinces_geojson({'type':'FeatureCollection','features':features})
    assert len(found)==5
    assert len(to_feature_collection(found)['features'])==5
    with pytest.raises(SourceError):
        read_provinces_geojson({'type':'FeatureCollection','features':features[:3]})


def test_spatial_dbscan_preserves_noise_and_annotates_records():
    example = pd.DataFrame({
        'latitude':[-2,-2.0001,-1.9998,-3],
        'longitude':[113,113.0001,113.0002,115],
        'province':['Kalimantan Tengah']*4,
        'confidence_group':['Tinggi','Nominal','Nominal','Nominal'],
        'source_name':['S-NPP','NOAA-20','NOAA-21','S-NPP'],
        'frp':[15,4,2,1],
        'acq_utc':pd.to_datetime(['2026-10-13T02:00Z','2026-10-13T03:00Z',
                                 '2026-10-14T03:00Z','2026-10-12T01:00Z'],utc=True)
    })
    grouped, report = cluster_detections(example,eps_km=2,min_records=3)
    assert len(report)==1
    assert len(grouped)==4
    assert (grouped.cluster_id==-1).sum()==1
    assert report.iloc[0].detections==3
    assert report.iloc[0].sensors==3
    assert report.iloc[0].days_utc==2
    assert report.iloc[0].screening_flag=='Tinjau ulang deteksi berulang'


def test_time_window_excludes_old_and_future_data():
    raw = pd.DataFrame({'acq_utc':pd.to_datetime(['2026-10-14T03:00Z',
                                                 '2026-10-12T00:00Z',
                                                 '2026-10-14T08:00Z'],utc=True)})
    valid = temporal_filter(raw,24,NOW)
    assert len(valid)==1


def test_geojson_exports_mode_and_no_fake_incident_area():
    raw = demo_detections(now=NOW, n=10)
    data,_ = normalize_firms(raw,NOW)
    geo = json.loads(detections_geojson(data, "DEMO_SINTETIS"))
    assert len(geo['features'])==10
    assert all(f['properties']['data_status']=='DEMO_SINTETIS' for f in geo['features'])
    assert not any('burned_area' in f['properties'] for f in geo['features'])


class FakeResponse:
    status_code = 200
    text = 'latitude,longitude,acq_date,acq_time,confidence,frp\n-2.12,113.8,2026-10-13,0035,h,23.4\n'
    def raise_for_status(self): return None


def test_nasa_endpoint_sensor_chunk_and_secret_leak_prevention():
    calls = []
    def getter(url, **kwargs):
        calls.append(url)
        return FakeResponse()
    frame = _fetch_sensor_chunk('x'*20,'NOAA-21',date(2026,10,13),2,getter=getter)
    assert 'VIIRS_NOAA21_NRT' in calls[0]
    assert '/108,-4.6,119.4,4.5/2/2026-10-13' in calls[0]
    assert frame.iloc[0].source_name == 'NOAA-21'


def test_fetch_multi_sensor_with_chunks():
    def getter(url,**kwargs): return FakeResponse()
    raw,warnings = fetch_firms('x'*20,['S-NPP','NOAA-20'],7,date(2026,10,14),getter=getter)
    assert len(raw)==4  # two 5/2-day requests per sensor
    assert warnings==[]


def test_detect_empty_cluster():
    df = pd.DataFrame({'latitude':[],'longitude':[]})
    out,clusters = cluster_detections(df)
    assert clusters.empty
    assert 'cluster_id' in out


def test_zero_observations_is_valid_not_server_error():
    class NoData:
        text='No data available for this period'
        def raise_for_status(self): return None
    def getter(url, **kwargs): return NoData()
    raw, warnings = fetch_firms('x'*20, ['S-NPP'], 3, date(2026,10,14), getter=getter)
    assert raw.empty
    assert warnings == []
