/**
 * KALIMANTAN FIRE MONITOR - Google Earth Engine Code Editor
 * Version: 2026-10-14 / prototype 0.1
 * Data: NASA/LANCE/SNPP_VIIRS/C2 (VIIRS S-NPP 375 m, NRT)
 * Boundary: FAO/GAUL/2015/level1 (administrative boundaries, not legal authority)
 * Context: ESA/WorldCover/v200 (2021 land cover)
 *
 * Operational caveats:
 * - Date is LAST AVAILABLE dataset date, NOT guaranteed to be current day.
 * - Pixel-day detections are NOT unique fire incidents or burned area (ha).
 * - Confidence 0/1/2 = low/nominal/high for detected fire pixels.
 * - Missing/cloud-obscured observations do not imply fire absence.
 * - NASA NRT data should be checked against independently verified field reports.
 * - Use for situational awareness, NOT life/property-critical navigation.
 */

// ---------------------------------------------------------------------------
// 1. Area of interest: Indonesian provinces on Borneo (Kalimantan)
// ---------------------------------------------------------------------------
var admin1 = ee.FeatureCollection('FAO/GAUL/2015/level1');
var kalimantan = admin1
  .filter(ee.Filter.eq('ADM0_NAME', 'Indonesia'))
  .filter(ee.Filter.inList('ADM1_NAME', [
    'Kalimantan Barat', 'Kalimantan Tengah', 'Kalimantan Selatan',
    'Kalimantan Timur', 'Kalimantan Utara'
  ]));
var aoi = kalimantan.geometry();

// Always inspect this result; outdated boundaries may differ from current admin.
print('Provinces found (expect 5)', kalimantan.aggregate_array('ADM1_NAME'));

// ---------------------------------------------------------------------------
// 2. Get LAST AVAILABLE NRT VIIRS image (do not assume today is ingested)
// ---------------------------------------------------------------------------
var windowEnd = ee.Date(Date.now()).advance(1, 'day');
var windowStart = windowEnd.advance(-14, 'day');
var viirs = ee.ImageCollection('NASA/LANCE/SNPP_VIIRS/C2')
  .filterBounds(aoi)
  .filterDate(windowStart, windowEnd);

print('Available VIIRS images in last 14 calendar days', viirs.size());

var latest = ee.Image(viirs.sort('system:time_start', false).first());
var latestDate = ee.Date(latest.get('system:time_start'));
var start3 = latestDate.advance(-2, 'day');
var end3 = latestDate.advance(1, 'day');
var days3 = viirs.filterDate(start3, end3);

print('LAST AVAILABLE observation date (UTC)', latestDate.format('YYYY-MM-dd'));
print('3-day available-data window, UTC', start3.format('YYYY-MM-dd'),
      end3.format('YYYY-MM-dd'), 'end exclusive');
print('Images in 3-day window', days3.size());

// ---------------------------------------------------------------------------
// 3. Daily detection pixel counts (NOT number of unique incidents)
// ---------------------------------------------------------------------------
function highFire(img) {
  var conf = img.select('confidence');
  return conf.eq(2).unmask(0).rename('high_pixel_day').toByte().clip(aoi);
}
function nominalPlusHigh(img) {
  var conf = img.select('confidence');
  return conf.gte(1).unmask(0).rename('nomhigh_pixel_day').toByte().clip(aoi);
}

var high3 = days3.map(highFire).sum()
  .rename('high_detection_pixel_days').clip(aoi);
var nomHigh3 = days3.map(nominalPlusHigh).sum()
  .rename('nominal_high_detection_pixel_days').clip(aoi);

// Maximum observed FRP over nominal/high pixels (MW), not burned area.
var maxFRP = days3.map(function(img) {
  return img.select('frp')
    .updateMask(img.select('confidence').gte(1))
    .rename('frp_max_MW')
    .clip(aoi);
}).max();

// ---------------------------------------------------------------------------
// 4. Map layers (optical land cover is a 2021 contextual baseline only)
// ---------------------------------------------------------------------------
Map.centerObject(kalimantan, 6);
Map.setOptions('SATELLITE');
var provinceStyle = kalimantan.style({
  color: 'FFFFFF', fillColor: '00000000', width: 1
});

var worldcover2021 = ee.ImageCollection('ESA/WorldCover/v200')
  .mosaic().select('Map').clip(aoi);
var trees2021 = worldcover2021.eq(10).selfMask();

Map.addLayer(trees2021, {palette: ['008A45']},
  'Tree cover - ESA WorldCover 2021 (historic context)', false);
Map.addLayer(maxFRP, {min: 0, max: 100,
  palette: ['FFFFB2', 'FEB24C', 'F03B20', 'BD0026']},
  'Maximum detected FRP (MW), nominal/high, 3 data-days', false);
Map.addLayer(nomHigh3.updateMask(nomHigh3.gt(0)), {
  min: 1, max: 3, palette: ['FFDF80', 'FF9E2C', 'FF5500']
}, 'Nominal + high: detection pixel-days (latest 3 data-days)', true);
Map.addLayer(high3.updateMask(high3.gt(0)), {
  min: 1, max: 3, palette: ['FF5555', 'D40000', '6D0012']
}, 'High-confidence: detection pixel-days (latest 3 data-days)', true);

Map.addLayer(latest.select('confidence').eq(1).selfMask().clip(aoi),
  {palette: ['FFD932']}, 'Nominal fire pixels - last available day', false);
Map.addLayer(latest.select('confidence').eq(2).selfMask().clip(aoi),
  {palette: ['FF0000']}, 'High-confidence fire pixels - last available day', true);
Map.addLayer(provinceStyle, {}, 'Kalimantan provinces (GAUL 2015)', true);

// ---------------------------------------------------------------------------
// 5. Quick provincial audit (pixel-day counts, not unique fires)
// ---------------------------------------------------------------------------
var provincialStats = high3.addBands(nomHigh3).reduceRegions({
  collection: kalimantan,
  reducer: ee.Reducer.sum(),
  scale: 375,
  tileScale: 8
}).map(function(ft) {
  return ee.Feature(null, {
    province: ft.get('ADM1_NAME'),
    high_detection_pixel_days: ft.get('high_detection_pixel_days'),
    nominal_high_detection_pixel_days: ft.get('nominal_high_detection_pixel_days'),
    latest_source_day_utc: latestDate.format('YYYY-MM-dd'),
    three_day_start_utc: start3.format('YYYY-MM-dd'),
    product: 'NASA/LANCE/SNPP_VIIRS/C2',
    note: 'Pixel-days, not unique fires; single satellite S-NPP only'
  });
});
print('Provincial pixel-day detection summary', provincialStats);

// ---------------------------------------------------------------------------
// 6. Exports (go to Tasks tab and press Run on the desired job)
// ---------------------------------------------------------------------------
Export.table.toDrive({
  collection: provincialStats,
  description: 'Kalimantan_VIIRS_Provincial_PixelDay_Summary',
  folder: 'Karhutla_Kalimantan',
  fileFormat: 'CSV'
});
Export.image.toDrive({
  image: high3.addBands(nomHigh3).toInt16(),
  description: 'Kalimantan_VIIRS_3Day_FireDetection_PixelDays',
  folder: 'Karhutla_Kalimantan',
  region: aoi,
  scale: 375,
  maxPixels: 1e13,
  fileFormat: 'GeoTIFF'
});

// Detection pixel centroids across three latest available data-days.
// Positions are snapped to raster centers and may repeat across dates.
var detectionCentroids = high3.addBands(nomHigh3)
  .updateMask(nomHigh3.gt(0))
  .sample({region: aoi, scale: 375, geometries: true, tileScale: 8});
print('Active detection pixel centroids (nominal/high)', detectionCentroids.size());
Export.table.toDrive({
  collection: detectionCentroids,
  description: 'Kalimantan_VIIRS_3Day_Detection_PixelCentroids',
  folder: 'Karhutla_Kalimantan',
  fileFormat: 'GeoJSON'
});
